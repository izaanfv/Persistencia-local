import 'package:flutter/material.dart';
import 'screens/bienvenida_interfaz_screen.dart';

// Entrada de la actividad de Diseño de Interfaces.
// Se ejecuta con: flutter run -t lib/main_interfaces.dart
void main() {
  runApp(const HabitosInterfazApp());
}

// Un único MaterialApp. No guarda estado, por eso es StatelessWidget.
class HabitosInterfazApp extends StatelessWidget {
  const HabitosInterfazApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HabitosApp',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: Colors.teal),
      home: const BienvenidaInterfazScreen(),
    );
  }
}
