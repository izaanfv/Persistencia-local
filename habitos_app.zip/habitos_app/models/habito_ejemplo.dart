import 'package:flutter/material.dart';

// Hábito de ejemplo (solo en memoria, sin guardar).
// Lo usamos para pasar datos entre pantallas.
class HabitoEjemplo {
  final String nombre;
  final String color; // nombre del color: 'Azul', 'Verde' o 'Naranja'

  const HabitoEjemplo({required this.nombre, required this.color});

  // Los tres colores disponibles: nombre -> color de Flutter
  static const Map<String, Color> colores = {
    'Azul': Colors.blue,
    'Verde': Colors.green,
    'Naranja': Colors.orange,
  };

  // Color de Flutter que corresponde al nombre guardado
  Color get colorFlutter => colores[color] ?? Colors.blue;
}
