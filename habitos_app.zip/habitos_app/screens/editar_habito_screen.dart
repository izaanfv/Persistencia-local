import 'package:flutter/material.dart';
import '../models/habito_ejemplo.dart';

// Pantalla 3: Editar hábito. Cambia el nombre y el color.
class EditarHabitoScreen extends StatefulWidget {
  // Hábito actual, que recibe de la pantalla principal
  final HabitoEjemplo habito;

  const EditarHabitoScreen({super.key, required this.habito});

  @override
  State<EditarHabitoScreen> createState() => _EditarHabitoScreenState();
}

class _EditarHabitoScreenState extends State<EditarHabitoScreen> {
  // Controlador del campo de texto (fuera de build)
  final _nombreCtrl = TextEditingController();
  late String _colorElegido; // color seleccionado ahora

  // Al abrir, ponemos el nombre y el color que nos han pasado
  @override
  void initState() {
    super.initState();
    _nombreCtrl.text = widget.habito.nombre;
    _colorElegido = widget.habito.color;
  }

  @override
  void dispose() {
    _nombreCtrl.dispose();
    super.dispose();
  }

  // Guardar: vuelve a la principal devolviendo el hábito nuevo
  void _guardar() {
    final nombre = _nombreCtrl.text.trim();
    Navigator.pop(
      context,
      HabitoEjemplo(
        // si el nombre está vacío, mantenemos el anterior
        nombre: nombre.isEmpty ? widget.habito.nombre : nombre,
        color: _colorElegido,
      ),
    );
  }

  // Cancelar: vuelve sin devolver nada (null)
  void _cancelar() {
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Editar hábito')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _nombreCtrl,
              decoration: const InputDecoration(
                labelText: 'Nombre del hábito',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 24),
            const Text('Elige un color:', style: TextStyle(fontSize: 18)),
            const SizedBox(height: 8),
            // Los tres botones de color, en una fila
            Row(
              children: HabitoEjemplo.colores.entries.map((c) {
                final seleccionado = _colorElegido == c.key;
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: c.value,
                        foregroundColor: Colors.white,
                      ),
                      onPressed: () => setState(() => _colorElegido = c.key),
                      // El ✓ indica cuál está seleccionado
                      child: Text(seleccionado ? '✓ ${c.key}' : c.key),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 8),
            Text('Color seleccionado: $_colorElegido'),
            const SizedBox(height: 32),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _cancelar,
                    child: const Text('Cancelar'),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _guardar,
                    child: const Text('Guardar'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
