import 'package:flutter/material.dart';
import '../models/habito_ejemplo.dart';
import 'editar_habito_screen.dart';

// Pantalla 2: Principal. Saluda y muestra la ficha del hábito.
class PrincipalInterfazScreen extends StatefulWidget {
  // Datos que recibe de la pantalla de bienvenida
  final String nombre;
  final String objetivo;

  const PrincipalInterfazScreen({
    super.key,
    required this.nombre,
    required this.objetivo,
  });

  @override
  State<PrincipalInterfazScreen> createState() =>
      _PrincipalInterfazScreenState();
}

class _PrincipalInterfazScreenState extends State<PrincipalInterfazScreen> {
  // Hábito de ejemplo guardado en memoria
  HabitoEjemplo _habito =
      const HabitoEjemplo(nombre: 'Beber agua', color: 'Azul');
  bool _completado = false;

  // Abre el editor y espera (await) el resultado
  Future<void> _editar() async {
    final resultado = await Navigator.push<HabitoEjemplo>(
      context,
      MaterialPageRoute(
        builder: (_) => EditarHabitoScreen(habito: _habito),
      ),
    );

    // Si la pantalla ya no existe, no hacemos nada
    if (!mounted) return;
    // Si el resultado es null (Cancelar o flecha), no cambiamos nada
    if (resultado != null) {
      setState(() => _habito = resultado);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pantalla principal')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '¡Hola, ${widget.nombre}!',
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              'Objetivo diario: ${widget.objetivo} hábitos',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 24),
            // Ficha del hábito
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Icon(Icons.water_drop, size: 40, color: _habito.colorFlutter),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _habito.nombre,
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text('Color: ${_habito.color}'),
                          const SizedBox(height: 4),
                          Text(_completado ? 'Estado: completado' : 'Estado: pendiente'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _editar,
              child: const Text('Editar hábito'),
            ),
            const SizedBox(height: 8),
            // Extra: marcar o desmarcar el hábito
            OutlinedButton(
              onPressed: () => setState(() => _completado = !_completado),
              child: Text(_completado ? 'Desmarcar' : 'Marcar como completado'),
            ),
          ],
        ),
      ),
    );
  }
}
