import 'package:flutter/material.dart';
import 'principal_interfaz_screen.dart';

// Pantalla 1: Bienvenida. Pide nombre y objetivo diario.
class BienvenidaInterfazScreen extends StatefulWidget {
  const BienvenidaInterfazScreen({super.key});

  @override
  State<BienvenidaInterfazScreen> createState() =>
      _BienvenidaInterfazScreenState();
}

class _BienvenidaInterfazScreenState extends State<BienvenidaInterfazScreen> {
  // Un controlador por cada campo, creados fuera de build
  final _nombreCtrl = TextEditingController();
  final _objetivoCtrl = TextEditingController();

  // Liberamos los controladores al cerrar la pantalla
  @override
  void dispose() {
    _nombreCtrl.dispose();
    _objetivoCtrl.dispose();
    super.dispose();
  }

  // Abre la pantalla principal y le pasa los datos por el constructor
  void _comenzar() {
    final nombre = _nombreCtrl.text.trim();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PrincipalInterfazScreen(
          nombre: nombre.isEmpty ? 'Usuario' : nombre,
          objetivo: _objetivoCtrl.text.trim(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bienvenida')),
      body: Center(
        // SingleChildScrollView: evita que el teclado tape los campos
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'HabitosApp',
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 32),
              TextField(
                controller: _nombreCtrl,
                decoration: const InputDecoration(
                  labelText: 'Nombre del usuario',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _objetivoCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Objetivo diario de hábitos',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _comenzar,
                child: const Text('Comenzar'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
