import 'package:intl/intl.dart';

// MODELO: un hábito. Tiene toJson/fromJson para poder guardarlo
// como texto en shared_preferences.
class Habito {
  final String id; // identificador único
  String nombre;
  int color; // el color se guarda como número
  List<String> fechasCompletadas; // días hechos, ej: "2026-10-16"

  Habito({
    required this.id,
    required this.nombre,
    required this.color,
    List<String>? fechasCompletadas,
  }) : fechasCompletadas = fechasCompletadas ?? [];

  // Colores que se pueden elegir
  static const List<int> coloresDisponibles = [
    0xFFE53935, // rojo
    0xFF1E88E5, // azul
    0xFF43A047, // verde
    0xFFFB8C00, // naranja
    0xFF8E24AA, // morado
    0xFF00ACC1, // cian
  ];

  // intl: librería para dar formato a fechas.
  // Aquí convierte una fecha en texto: "2026-10-16".
  static String claveFecha(DateTime fecha) =>
      DateFormat('yyyy-MM-dd').format(fecha);

  // ¿Está hecho hoy?
  bool get completadoHoy =>
      fechasCompletadas.contains(claveFecha(DateTime.now()));

  // Si hoy está hecho lo quita, y si no, lo añade
  void alternarHoy() {
    final hoy = claveFecha(DateTime.now());
    if (fechasCompletadas.contains(hoy)) {
      fechasCompletadas.remove(hoy);
    } else {
      fechasCompletadas.add(hoy);
    }
  }

  // Total de días completados
  int get totalDias => fechasCompletadas.length;

  // Racha: días seguidos hechos. Si hoy aún no está hecho,
  // empezamos a contar desde ayer.
  int get rachaActual {
    final ahora = DateTime.now();
    var dia = DateTime(ahora.year, ahora.month, ahora.day);
    if (!fechasCompletadas.contains(claveFecha(dia))) {
      dia = DateTime(dia.year, dia.month, dia.day - 1);
    }
    int racha = 0;
    while (fechasCompletadas.contains(claveFecha(dia))) {
      racha++;
      dia = DateTime(dia.year, dia.month, dia.day - 1);
    }
    return racha;
  }

  // Objeto -> Map (para guardar con jsonEncode)
  Map<String, dynamic> toJson() => {
        'id': id,
        'nombre': nombre,
        'color': color,
        'fechasCompletadas': fechasCompletadas,
      };

  // Map (que viene de jsonDecode) -> Objeto
  factory Habito.fromJson(Map<String, dynamic> json) => Habito(
        id: json['id'] as String,
        nombre: json['nombre'] as String,
        color: json['color'] as int,
        fechasCompletadas:
            List<String>.from(json['fechasCompletadas'] ?? <String>[]),
      );
}
