import 'package:flutter/material.dart';
import 'screens/bienvenida_screen.dart';
import 'screens/principal_screen.dart';
import 'services/preferencias_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const HabitosApp());
}

// StatefulWidget porque el tema y la letra cambian mientras
// la app está abierta (tiene estado).
class HabitosApp extends StatefulWidget {
  const HabitosApp({super.key});

  @override
  State<HabitosApp> createState() => _HabitosAppState();
}

class _HabitosAppState extends State<HabitosApp> {
  final _servicio = PreferenciasService();

  bool _cargando = true; // true = mostramos el indicador de carga
  bool _bienvenidaHecha = false;
  bool _temaOscuro = false;
  double _tamanoLetra = PreferenciasService.tamanoLetraPorDefecto;

  @override
  void initState() {
    super.initState();
    _iniciar();
  }

  // initState no puede ser async, así que llama a este método
  Future<void> _iniciar() async {
    await _servicio.registrarApertura(); // suma 1 apertura
    await _cargarAjustes();
    final hecha = await _servicio.bienvenidaCompletada();
    setState(() {
      _bienvenidaHecha = hecha;
      _cargando = false; // ya hemos leído todo
    });
  }

  // Lee el tema y la letra guardados. Ajustes lo llama
  // cuando el usuario cambia algo.
  Future<void> _cargarAjustes() async {
    final oscuro = await _servicio.leerTemaOscuro();
    final tamano = await _servicio.leerTamanoLetra();
    if (!mounted) return;
    setState(() {
      _temaOscuro = oscuro;
      _tamanoLetra = tamano;
    });
  }

  // Al terminar la bienvenida pasamos a la principal
  void _alTerminarBienvenida() {
    setState(() => _bienvenidaHecha = true);
  }

  // Tras borrar los datos volvemos a la bienvenida
  Future<void> _alBorrarTodo() async {
    await _cargarAjustes();
    setState(() => _bienvenidaHecha = false);
  }

  @override
  Widget build(BuildContext context) {
    // Elegimos qué pantalla mostrar según el estado
    Widget inicio;
    if (_cargando) {
      inicio = const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    } else if (_bienvenidaHecha) {
      inicio = PrincipalScreen(
        alCambiarAjustes: _cargarAjustes,
        alBorrarTodo: _alBorrarTodo,
      );
    } else {
      inicio = BienvenidaScreen(alTerminar: _alTerminarBienvenida);
    }

    return MaterialApp(
      title: 'HabitosApp',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.teal,
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        colorSchemeSeed: Colors.teal,
        brightness: Brightness.dark,
      ),
      themeMode: _temaOscuro ? ThemeMode.dark : ThemeMode.light,
      // Cambia el tamaño de todos los textos (16 = normal)
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context)
            .copyWith(textScaler: TextScaler.linear(_tamanoLetra / 16)),
        child: child!,
      ),
      home: inicio,
    );
  }
}
