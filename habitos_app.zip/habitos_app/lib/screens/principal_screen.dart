import 'package:flutter/material.dart';
import '../models/habito.dart';
import '../services/preferencias_service.dart';
import '../widgets/habito_tile.dart';
import 'ajustes_screen.dart';
import 'estadisticas_screen.dart';
import 'habitos_screen.dart';

// Pantalla principal: saludo, progreso del día y lista de hábitos.
class PrincipalScreen extends StatefulWidget {
  final VoidCallback alCambiarAjustes;
  final VoidCallback alBorrarTodo;

  const PrincipalScreen({
    super.key,
    required this.alCambiarAjustes,
    required this.alBorrarTodo,
  });

  @override
  State<PrincipalScreen> createState() => _PrincipalScreenState();
}

class _PrincipalScreenState extends State<PrincipalScreen> {
  final _servicio = PreferenciasService();

  bool _cargando = true;
  String _nombre = '';
  int _objetivo = PreferenciasService.objetivoPorDefecto;
  bool _ocultarCompletados = false;
  List<Habito> _habitos = [];

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  // Lee de shared_preferences todo lo que necesita la pantalla
  Future<void> _cargar() async {
    final nombre = await _servicio.leerNombre();
    final objetivo = await _servicio.leerObjetivo();
    final ocultar = await _servicio.leerOcultarCompletados();
    final habitos = await _servicio.cargarHabitos();
    if (!mounted) return; // si la pantalla ya no existe, no hacemos nada
    setState(() {
      _nombre = nombre ?? ''; // si es null, texto vacío
      _objetivo = objetivo;
      _ocultarCompletados = ocultar;
      _habitos = habitos;
      _cargando = false;
    });
  }

  // Marca o desmarca un hábito y lo guarda
  Future<void> _marcar(Habito habito) async {
    setState(() => habito.alternarHoy()); // setState redibuja la pantalla
    await _servicio.guardarHabitos(_habitos); // se guarda en local
  }

  // Abre otra pantalla. Al volver (await) recargamos los datos
  // por si han cambiado.
  Future<void> _abrir(Widget pantalla) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => pantalla),
    );
    _cargar();
  }

  @override
  Widget build(BuildContext context) {
    // Mientras se leen los datos, mostramos el indicador de carga
    if (_cargando) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final hechos = _habitos.where((h) => h.completadoHoy).length;
    final progreso = (hechos / _objetivo).clamp(0.0, 1.0);
    // Si "ocultar completados" está activo, quitamos los ya hechos
    final visibles = _ocultarCompletados
        ? _habitos.where((h) => !h.completadoHoy).toList()
        : _habitos;

    return Scaffold(
      appBar: AppBar(
        title: const Text('HabitosApp'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_note),
            tooltip: 'Gestionar hábitos',
            onPressed: () => _abrir(const HabitosScreen()),
          ),
          IconButton(
            icon: const Icon(Icons.bar_chart),
            tooltip: 'Estadísticas',
            onPressed: () => _abrir(const EstadisticasScreen()),
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: 'Ajustes',
            onPressed: () => _abrir(AjustesScreen(
              alCambiarAjustes: widget.alCambiarAjustes,
              alBorrarTodo: widget.alBorrarTodo,
            )),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('¡Hola, $_nombre!',
                style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 8),
            Text('$hechos de $_objetivo hábitos hoy'),
            const SizedBox(height: 8),
            LinearProgressIndicator(value: progreso, minHeight: 10),
            const SizedBox(height: 16),
            Expanded(
              child: visibles.isEmpty
                  ? const Center(
                      child: Text(
                        'No hay hábitos que mostrar.\nCrea uno con el icono de arriba.',
                        textAlign: TextAlign.center,
                      ),
                    )
                  : ListView.builder(
                      itemCount: visibles.length,
                      itemBuilder: (context, i) => HabitoTile(
                        habito: visibles[i],
                        onChanged: (_) => _marcar(visibles[i]),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
