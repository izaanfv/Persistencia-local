import 'package:flutter/material.dart';
import '../services/preferencias_service.dart';

// Ajustes: tema, tamaño de letra, ocultar completados y borrar datos.
class AjustesScreen extends StatefulWidget {
  final VoidCallback alCambiarAjustes;
  final VoidCallback alBorrarTodo;

  const AjustesScreen({
    super.key,
    required this.alCambiarAjustes,
    required this.alBorrarTodo,
  });

  @override
  State<AjustesScreen> createState() => _AjustesScreenState();
}

class _AjustesScreenState extends State<AjustesScreen> {
  final _servicio = PreferenciasService();

  bool _cargando = true;
  bool _temaOscuro = false;
  bool _ocultarCompletados = false;
  double _tamanoLetra = PreferenciasService.tamanoLetraPorDefecto;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  // Lee los ajustes guardados para mostrarlos en pantalla
  Future<void> _cargar() async {
    final oscuro = await _servicio.leerTemaOscuro();
    final ocultar = await _servicio.leerOcultarCompletados();
    final tamano = await _servicio.leerTamanoLetra();
    if (!mounted) return;
    setState(() {
      _temaOscuro = oscuro;
      _ocultarCompletados = ocultar;
      _tamanoLetra = tamano;
      _cargando = false;
    });
  }

  Future<void> _cambiarTema(bool valor) async {
    setState(() => _temaOscuro = valor);
    await _servicio.guardarTemaOscuro(valor); // se guarda (bool)
    widget.alCambiarAjustes(); // avisa a main.dart para cambiar el tema
  }

  Future<void> _cambiarOcultar(bool valor) async {
    setState(() => _ocultarCompletados = valor);
    await _servicio.guardarOcultarCompletados(valor); // se guarda (bool)
  }

  // Se llama al soltar el slider (no mientras se arrastra)
  Future<void> _guardarTamano(double valor) async {
    await _servicio.guardarTamanoLetra(valor); // se guarda (double)
    widget.alCambiarAjustes();
  }

  Future<void> _borrarDatos() async {
    // Pedimos confirmación antes de borrar
    final confirmar = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Borrar todos los datos'),
        content: const Text(
            'Se borrarán hábitos, estadísticas y ajustes. Esta acción no se puede deshacer.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Borrar'),
          ),
        ],
      ),
    );
    if (confirmar != true) return;

    await _servicio.borrarTodo(); // borra todo lo guardado
    widget.alBorrarTodo(); // main.dart vuelve a mostrar la bienvenida
    if (!mounted) return;
    // Volvemos a la primera pantalla (que ahora es la bienvenida)
    Navigator.popUntil(context, (ruta) => ruta.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ajustes')),
      body: _cargando
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                SwitchListTile(
                  title: const Text('Tema oscuro'),
                  value: _temaOscuro,
                  onChanged: _cambiarTema,
                ),
                SwitchListTile(
                  title: const Text('Ocultar hábitos completados hoy'),
                  value: _ocultarCompletados,
                  onChanged: _cambiarOcultar,
                ),
                const SizedBox(height: 8),
                Text('Tamaño de letra: ${_tamanoLetra.round()}'),
                Slider(
                  value: _tamanoLetra,
                  min: 12,
                  max: 24,
                  divisions: 6,
                  label: _tamanoLetra.round().toString(),
                  onChanged: (v) => setState(() => _tamanoLetra = v),
                  onChangeEnd: _guardarTamano,
                ),
                const SizedBox(height: 24),
                FilledButton.icon(
                  onPressed: _borrarDatos,
                  icon: const Icon(Icons.delete_forever),
                  label: const Text('Borrar todos los datos'),
                ),
              ],
            ),
    );
  }
}
