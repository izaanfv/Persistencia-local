import 'package:flutter/material.dart';
import '../services/preferencias_service.dart';

// Pantalla de bienvenida: solo sale la primera vez.
class BienvenidaScreen extends StatefulWidget {
  final VoidCallback alTerminar;

  const BienvenidaScreen({super.key, required this.alTerminar});

  @override
  State<BienvenidaScreen> createState() => _BienvenidaScreenState();
}

class _BienvenidaScreenState extends State<BienvenidaScreen> {
  final _servicio = PreferenciasService();
  final _formKey = GlobalKey<FormState>();
  final _nombreCtrl = TextEditingController();
  final _objetivoCtrl = TextEditingController();

  @override
  void dispose() {
    _nombreCtrl.dispose();
    _objetivoCtrl.dispose();
    super.dispose();
  }

  Future<void> _empezar() async {
    // Si algún campo no es válido, no seguimos
    if (!_formKey.currentState!.validate()) return;

    // Guardamos nombre, objetivo y que la bienvenida ya se hizo
    await _servicio.guardarBienvenida(
      _nombreCtrl.text.trim(),
      int.parse(_objetivoCtrl.text.trim()),
    );
    widget.alTerminar(); // avisa a main.dart para ir a la principal
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bienvenido a HabitosApp')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.check_circle_outline, size: 80),
              const SizedBox(height: 24),
              TextFormField(
                controller: _nombreCtrl,
                decoration: const InputDecoration(
                  labelText: '¿Cómo te llamas?',
                  border: OutlineInputBorder(),
                ),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Escribe tu nombre' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _objetivoCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Objetivo diario (nº de hábitos)',
                  border: OutlineInputBorder(),
                ),
                validator: (v) {
                  final n = int.tryParse(v?.trim() ?? '');
                  if (n == null || n <= 0) return 'Escribe un número mayor que 0';
                  return null;
                },
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: _empezar,
                child: const Text('Empezar'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
