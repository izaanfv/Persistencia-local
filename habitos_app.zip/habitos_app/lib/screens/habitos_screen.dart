import 'package:flutter/material.dart';
import '../models/habito.dart';
import '../services/preferencias_service.dart';

// Gestión de hábitos: crear, editar y borrar.
class HabitosScreen extends StatefulWidget {
  const HabitosScreen({super.key});

  @override
  State<HabitosScreen> createState() => _HabitosScreenState();
}

class _HabitosScreenState extends State<HabitosScreen> {
  final _servicio = PreferenciasService();

  bool _cargando = true;
  List<Habito> _habitos = [];

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final habitos = await _servicio.cargarHabitos();
    if (!mounted) return;
    setState(() {
      _habitos = habitos;
      _cargando = false;
    });
  }

  // Ventana para crear (habito == null) o editar un hábito
  Future<void> _mostrarDialogo({Habito? habito}) async {
    final controlador = TextEditingController(text: habito?.nombre ?? '');
    int colorElegido = habito?.color ?? Habito.coloresDisponibles.first;

    final guardar = await showDialog<bool>(
      context: context,
      // StatefulBuilder permite que el color elegido se vea
      // marcado dentro de la ventana
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogo) => AlertDialog(
          title: Text(habito == null ? 'Nuevo hábito' : 'Editar hábito'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: controlador,
                decoration: const InputDecoration(labelText: 'Nombre'),
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                children: Habito.coloresDisponibles.map((c) {
                  return GestureDetector(
                    onTap: () => setDialogo(() => colorElegido = c),
                    child: CircleAvatar(
                      backgroundColor: Color(c),
                      radius: 16,
                      child: colorElegido == c
                          ? const Icon(Icons.check,
                              color: Colors.white, size: 18)
                          : null,
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Guardar'),
            ),
          ],
        ),
      ),
    );

    final nombre = controlador.text.trim();
    if (!mounted || guardar != true || nombre.isEmpty) return;

    setState(() {
      if (habito == null) {
        // Crear: el id es la hora actual en milisegundos (no se repite)
        _habitos.add(Habito(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          nombre: nombre,
          color: colorElegido,
        ));
      } else {
        // Editar: cambiamos los datos del hábito
        habito.nombre = nombre;
        habito.color = colorElegido;
      }
    });
    await _servicio.guardarHabitos(_habitos); // se guarda en local
  }

  Future<void> _borrar(Habito habito) async {
    final confirmar = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Borrar hábito'),
        content: Text('¿Seguro que quieres borrar "${habito.nombre}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Borrar'),
          ),
        ],
      ),
    );
    if (!mounted || confirmar != true) return;

    setState(() => _habitos.remove(habito));
    await _servicio.guardarHabitos(_habitos); // se guarda en local
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Gestionar hábitos')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _mostrarDialogo(),
        child: const Icon(Icons.add),
      ),
      body: _cargando
          ? const Center(child: CircularProgressIndicator())
          : _habitos.isEmpty
              ? const Center(child: Text('Aún no tienes hábitos. Pulsa +'))
              : ListView.builder(
                  itemCount: _habitos.length,
                  itemBuilder: (context, i) {
                    final h = _habitos[i];
                    return ListTile(
                      leading:
                          CircleAvatar(backgroundColor: Color(h.color), radius: 12),
                      title: Text(h.nombre),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.edit),
                            onPressed: () => _mostrarDialogo(habito: h),
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete),
                            onPressed: () => _borrar(h),
                          ),
                        ],
                      ),
                    );
                  },
                ),
    );
  }
}
