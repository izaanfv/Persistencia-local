import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/habito.dart';
import '../services/preferencias_service.dart';

// Estadísticas: rachas, días completados y aperturas de la app.
class EstadisticasScreen extends StatefulWidget {
  const EstadisticasScreen({super.key});

  @override
  State<EstadisticasScreen> createState() => _EstadisticasScreenState();
}

class _EstadisticasScreenState extends State<EstadisticasScreen> {
  final _servicio = PreferenciasService();

  bool _cargando = true;
  List<Habito> _habitos = [];
  int _aperturas = 0;
  DateTime? _ultimaApertura; // puede ser null (el ? lo permite)

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final habitos = await _servicio.cargarHabitos();
    final aperturas = await _servicio.leerNumAperturas();
    final ultima = await _servicio.leerUltimaApertura();
    if (!mounted) return;
    setState(() {
      _habitos = habitos;
      _aperturas = aperturas;
      _ultimaApertura = ultima;
      _cargando = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    // intl: DateFormat muestra la fecha y la hora de forma legible
    final ultimaTexto = _ultimaApertura == null
        ? 'Sin datos'
        : DateFormat('dd/MM/yyyy HH:mm').format(_ultimaApertura!);

    return Scaffold(
      appBar: AppBar(title: const Text('Estadísticas')),
      body: _cargando
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.login),
                    title: Text('Veces que se ha abierto la app: $_aperturas'),
                    subtitle: Text('Última apertura: $ultimaTexto'),
                  ),
                ),
                const SizedBox(height: 8),
                Text('Hábitos',
                    style: Theme.of(context).textTheme.titleMedium),
                if (_habitos.isEmpty)
                  const Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text('Todavía no hay hábitos.'),
                  ),
                ..._habitos.map((h) => Card(
                      child: ListTile(
                        leading: CircleAvatar(
                            backgroundColor: Color(h.color), radius: 12),
                        title: Text(h.nombre),
                        subtitle: Text(
                          'Racha actual: ${h.rachaActual} días\n'
                          'Total de días completados: ${h.totalDias}',
                        ),
                        isThreeLine: true,
                      ),
                    )),
              ],
            ),
    );
  }
}
