import 'package:flutter/material.dart';
import '../models/habito.dart';

// StatelessWidget: no guarda estado, solo dibuja lo que recibe.
// Cuando se pulsa la casilla avisa con onChanged y la pantalla
// (que sí tiene estado) hace el cambio.
class HabitoTile extends StatelessWidget {
  final Habito habito;
  final ValueChanged<bool?> onChanged;

  const HabitoTile({
    super.key,
    required this.habito,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final color = Color(habito.color);
    return Card(
      child: CheckboxListTile(
        value: habito.completadoHoy,
        onChanged: onChanged,
        activeColor: color,
        secondary: CircleAvatar(backgroundColor: color, radius: 12),
        title: Text(
          habito.nombre,
          style: TextStyle(
            decoration:
                habito.completadoHoy ? TextDecoration.lineThrough : null,
          ),
        ),
        subtitle: Text('Racha: ${habito.rachaActual} días'),
      ),
    );
  }
}
