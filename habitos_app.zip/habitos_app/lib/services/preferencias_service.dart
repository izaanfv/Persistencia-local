import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/habito.dart';

// CLAVES: los nombres con los que guardamos cada dato.
// Están todas aquí para no escribir textos sueltos por el código.
class Claves {
  static const String nombre = 'nombre'; //                 String
  static const String objetivoDiario = 'objetivo_diario'; // int
  static const String numAperturas = 'num_aperturas'; //     int
  static const String ultimaApertura = 'ultima_apertura'; // String
  static const String bienvenidaHecha = 'bienvenida_hecha'; // bool
  static const String temaOscuro = 'tema_oscuro'; //         bool
  static const String ocultarCompletados = 'ocultar_completados'; // bool
  static const String tamanoLetra = 'tamano_letra'; //       double
  static const String habitos = 'habitos'; //                List<String>
}

// SERVICIO: aquí está TODO el acceso a SharedPreferences.
// Las pantallas llaman a estos métodos y nunca a SharedPreferences.
class PreferenciasService {
  // Valores por defecto, por si todavía no hay nada guardado
  static const int objetivoPorDefecto = 3;
  static const double tamanoLetraPorDefecto = 16.0;

  // Abre el almacenamiento. Es async porque tarda un poco.
  Future<SharedPreferences> get _prefs => SharedPreferences.getInstance();

  // ---------- BIENVENIDA ----------

  // La primera vez getBool devuelve null (no existe).
  // Con "?? false" lo tratamos como "aún no hecha".
  Future<bool> bienvenidaCompletada() async {
    final prefs = await _prefs;
    return prefs.getBool(Claves.bienvenidaHecha) ?? false;
  }

  Future<void> guardarBienvenida(String nombre, int objetivo) async {
    final prefs = await _prefs;
    await prefs.setString(Claves.nombre, nombre); //        String
    await prefs.setInt(Claves.objetivoDiario, objetivo); // int
    await prefs.setBool(Claves.bienvenidaHecha, true); //   bool
  }

  // String? porque puede ser null si no se guardó nunca
  Future<String?> leerNombre() async {
    final prefs = await _prefs;
    return prefs.getString(Claves.nombre);
  }

  Future<int> leerObjetivo() async {
    final prefs = await _prefs;
    return prefs.getInt(Claves.objetivoDiario) ?? objetivoPorDefecto;
  }

  // ---------- APERTURAS ----------

  // Se llama cada vez que se abre la app: suma 1 y guarda la fecha
  Future<void> registrarApertura() async {
    final prefs = await _prefs;
    final aperturas = prefs.getInt(Claves.numAperturas) ?? 0;
    await prefs.setInt(Claves.numAperturas, aperturas + 1);
    // La fecha se guarda como texto
    await prefs.setString(
        Claves.ultimaApertura, DateTime.now().toIso8601String());
  }

  Future<int> leerNumAperturas() async {
    final prefs = await _prefs;
    return prefs.getInt(Claves.numAperturas) ?? 0;
  }

  Future<DateTime?> leerUltimaApertura() async {
    final prefs = await _prefs;
    final texto = prefs.getString(Claves.ultimaApertura);
    if (texto == null) return null; // primera vez: no hay fecha
    return DateTime.parse(texto); // texto -> fecha
  }

  // ---------- HÁBITOS ----------

  // Leer: cada elemento de la lista es un hábito en texto JSON.
  // jsonDecode: texto -> Map, y fromJson: Map -> Habito.
  Future<List<Habito>> cargarHabitos() async {
    final prefs = await _prefs;
    final lista = prefs.getStringList(Claves.habitos); // null la 1ª vez
    if (lista == null) return [];
    return lista
        .map((texto) => Habito.fromJson(jsonDecode(texto)))
        .toList();
  }

  // Guardar: toJson: Habito -> Map, y jsonEncode: Map -> texto.
  Future<void> guardarHabitos(List<Habito> habitos) async {
    final prefs = await _prefs;
    final lista = habitos.map((h) => jsonEncode(h.toJson())).toList();
    await prefs.setStringList(Claves.habitos, lista);
  }

  // ---------- AJUSTES ----------

  Future<bool> leerTemaOscuro() async {
    final prefs = await _prefs;
    return prefs.getBool(Claves.temaOscuro) ?? false;
  }

  Future<void> guardarTemaOscuro(bool valor) async {
    final prefs = await _prefs;
    await prefs.setBool(Claves.temaOscuro, valor);
  }

  Future<bool> leerOcultarCompletados() async {
    final prefs = await _prefs;
    return prefs.getBool(Claves.ocultarCompletados) ?? false;
  }

  Future<void> guardarOcultarCompletados(bool valor) async {
    final prefs = await _prefs;
    await prefs.setBool(Claves.ocultarCompletados, valor);
  }

  Future<double> leerTamanoLetra() async {
    final prefs = await _prefs;
    return prefs.getDouble(Claves.tamanoLetra) ?? tamanoLetraPorDefecto;
  }

  Future<void> guardarTamanoLetra(double valor) async {
    final prefs = await _prefs;
    await prefs.setDouble(Claves.tamanoLetra, valor);
  }

  // ---------- BORRAR TODO ----------

  // clear() borra todas las claves: la app queda como recién instalada
  Future<void> borrarTodo() async {
    final prefs = await _prefs;
    await prefs.clear();
  }
}
