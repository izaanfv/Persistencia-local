import 'package:flutter/material.dart';
import 'pantallas/login_page.dart';
import 'pantallas/habitos_page.dart';
import 'servicios/preferencias_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  int? userId = await PreferenciasService.getUsuarioId();
  runApp(HabitosApp(estaLogueado: userId != null));
}

class HabitosApp extends StatelessWidget {
  final bool estaLogueado;

  const HabitosApp({super.key, required this.estaLogueado});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Hábitos App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: estaLogueado ? const HabitosPage() : const LoginPage(),
    );
  }
}
