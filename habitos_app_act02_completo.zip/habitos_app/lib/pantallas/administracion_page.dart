import 'package:flutter/material.dart';
import '../modelos/usuario.dart';
import '../modelos/habito.dart';
import '../servicios/base_datos.dart';

class AdministracionPage extends StatefulWidget {
  const AdministracionPage({super.key});

  @override
  State<AdministracionPage> createState() => _AdministracionPageState();
}

class _AdministracionPageState extends State<AdministracionPage> {
  List<Usuario> _usuarios = [];
  List<Habito> _habitos = [];

  @override
  void initState() {
    super.initState();
    _cargarTodo();
  }

  void _cargarTodo() async {
    var u = await BaseDatos.getTodosUsuarios();
    var h = await BaseDatos.getTodosHabitos();
    setState(() {
      _usuarios = u;
      _habitos = h;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Panel Administrador')),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: Text('Usuarios Registrados', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _usuarios.length,
              itemBuilder: (ctx, i) {
                final u = _usuarios[i];
                return ListTile(
                  title: Text('${u.usuario} (${u.rol})'),
                  subtitle: Text(u.email),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () async {
                      await BaseDatos.eliminarUsuario(u.id!);
                      _cargarTodo();
                    },
                  ),
                );
              },
            ),
            const Divider(),
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: Text('Todos los Hábitos', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _habitos.length,
              itemBuilder: (ctx, i) {
                final h = _habitos[i];
                return ListTile(
                  title: Text(h.nombre),
                  subtitle: Text('ID Usuario: ${h.usuarioId}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () async {
                      await BaseDatos.eliminarHabito(h.id!);
                      _cargarTodo();
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
