import 'package:flutter/material.dart';
import '../widgets/campo_texto_app.dart';
import '../widgets/boton_principal.dart';
import '../modelos/habito.dart';
import '../servicios/base_datos.dart';
import '../servicios/preferencias_service.dart';

class EditarHabitoPage extends StatefulWidget {
  final Habito? habito;
  const EditarHabitoPage({super.key, this.habito});

  @override
  State<EditarHabitoPage> createState() => _EditarHabitoPageState();
}

class _EditarHabitoPageState extends State<EditarHabitoPage> {
  final _nombreCtrl = TextEditingController();
  int _colorSeleccionado = Colors.blue.value;

  final List<Color> _colores = [
    Colors.blue,
    Colors.green,
    Colors.orange,
    Colors.purple,
    Colors.red,
  ];

  @override
  void initState() {
    super.initState();
    if (widget.habito != null) {
      _nombreCtrl.text = widget.habito!.nombre;
      _colorSeleccionado = widget.habito!.colorHex;
    }
  }

  void _guardar() async {
    if (_nombreCtrl.text.isEmpty) return;

    int? userId = await PreferenciasService.getUsuarioId();
    if (userId == null) return;

    if (widget.habito == null) {
      Habito nuevo = Habito(
        usuarioId: userId,
        nombre: _nombreCtrl.text,
        colorHex: _colorSeleccionado,
        fechasCompletado: '',
      );
      await BaseDatos.crearHabito(nuevo);
    } else {
      Habito editado = Habito(
        id: widget.habito!.id,
        usuarioId: widget.habito!.usuarioId,
        nombre: _nombreCtrl.text,
        colorHex: _colorSeleccionado,
        fechasCompletado: widget.habito!.fechasCompletado,
      );
      await BaseDatos.actualizarHabito(editado);
    }

    if (!mounted) return;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.habito == null ? 'Nuevo Hábito' : 'Editar Hábito')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            CampoTextoApp(etiqueta: 'Nombre del Hábito', controller: _nombreCtrl),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: _colores.map((color) {
                return GestureDetector(
                  onTap: () => setState(() => _colorSeleccionado = color.value),
                  child: CircleAvatar(
                    backgroundColor: color,
                    child: _colorSeleccionado == color.value
                        ? const Icon(Icons.check, color: Colors.white)
                        : null,
                  ),
                );
              }).toList(),
            ),
            const Spacer(),
            BotonPrincipal(texto: 'Guardar', onPressed: _guardar),
          ],
        ),
      ),
    );
  }
}
