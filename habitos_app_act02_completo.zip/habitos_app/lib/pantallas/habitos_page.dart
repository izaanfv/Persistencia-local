import 'package:flutter/material.dart';
import '../modelos/habito.dart';
import '../servicios/base_datos.dart';
import '../servicios/preferencias_service.dart';
import '../widgets/tarjeta_habito.dart';
import 'editar_habito_page.dart';
import 'estadisticas_page.dart';
import 'administracion_page.dart';
import 'login_page.dart';

class HabitosPage extends StatefulWidget {
  const HabitosPage({super.key});

  @override
  State<HabitosPage> createState() => _HabitosPageState();
}

class _HabitosPageState extends State<HabitosPage> {
  List<Habito> _habitos = [];
  int? _userId;
  String? _rol;

  @override
  void initState() {
    super.initState();
    _cargarDatos();
  }

  void _cargarDatos() async {
    _userId = await PreferenciasService.getUsuarioId();
    _rol = await PreferenciasService.getRol();
    if (_userId != null) {
      var lista = await BaseDatos.getHabitosUsuario(_userId!);
      setState(() {
        _habitos = lista;
      });
    }
  }

  void _confirmarBorrado(int id) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('¿Eliminar hábito?'),
        content: const Text('Esta acción no se puede deshacer.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
          TextButton(
            onPressed: () async {
              await BaseDatos.eliminarHabito(id);
              Navigator.pop(ctx);
              _cargarDatos();
            },
            child: const Text('Eliminar', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    String hoy = DateTime.now().toString().split(' ')[0];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mis Hábitos'),
        actions: [
          IconButton(
            icon: const Icon(Icons.bar_chart),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const EstadisticasPage())),
          ),
          if (_rol == 'administrador')
            IconButton(
              icon: const Icon(Icons.admin_panel_settings),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdministracionPage())),
            ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await PreferenciasService.cerrarSesion();
              if (!mounted) return;
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginPage()));
            },
          ),
        ],
      ),
      body: _habitos.isEmpty
          ? const Center(child: Text('No tienes hábitos registrados aún.'))
          : ListView.builder(
              itemCount: _habitos.length,
              itemBuilder: (ctx, i) {
                final habito = _habitos[i];
                bool completado = habito.fechasCompletado.split(',').contains(hoy);

                return TarjetaHabito(
                  nombre: habito.nombre,
                  colorHex: habito.colorHex,
                  completadoHoy: completado,
                  onCompletar: () async {
                    await BaseDatos.marcarHabitoCompletado(habito);
                    _cargarDatos();
                  },
                  onEditar: () async {
                    await Navigator.push(context, MaterialPageRoute(builder: (_) => EditarHabitoPage(habito: habito)));
                    _cargarDatos();
                  },
                  onEliminar: () => _confirmarBorrado(habito.id!),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => const EditarHabitoPage()));
          _cargarDatos();
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
