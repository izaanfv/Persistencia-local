import 'package:flutter/material.dart';
import '../widgets/campo_texto_app.dart';
import '../widgets/boton_principal.dart';
import '../modelos/usuario.dart';
import '../servicios/base_datos.dart';

class RegistroPage extends StatefulWidget {
  const RegistroPage({super.key});

  @override
  State<RegistroPage> createState() => _RegistroPageState();
}

class _RegistroPageState extends State<RegistroPage> {
  final _usuarioCtrl = TextEditingController();
  final _nombreCtrl = TextEditingController();
  final _apellidosCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();

  void _registrar() async {
    if (_usuarioCtrl.text.isEmpty || _passCtrl.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Por favor rellena los datos básicos.')),
      );
      return;
    }

    Usuario nuevo = Usuario(
      usuario: _usuarioCtrl.text,
      nombre: _nombreCtrl.text,
      apellidos: _apellidosCtrl.text,
      email: _emailCtrl.text,
      contrasena: _passCtrl.text,
      fechaCreacion: DateTime.now().toString().split(' ')[0],
      rol: 'usuario',
    );

    await BaseDatos.registrarUsuario(nuevo);
    if (!mounted) return;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Registro de Usuario')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            CampoTextoApp(etiqueta: 'Usuario', controller: _usuarioCtrl),
            CampoTextoApp(etiqueta: 'Nombre', controller: _nombreCtrl),
            CampoTextoApp(etiqueta: 'Apellidos', controller: _apellidosCtrl),
            CampoTextoApp(etiqueta: 'Email', controller: _emailCtrl),
            CampoTextoApp(etiqueta: 'Contraseña', controller: _passCtrl, ocultarTexto: true),
            BotonPrincipal(texto: 'Registrarse', onPressed: _registrar),
          ],
        ),
      ),
    );
  }
}
