import 'package:flutter/material.dart';
import '../modelos/habito.dart';
import '../modelos/estadistica.dart';
import '../servicios/base_datos.dart';
import '../servicios/preferencias_service.dart';
import '../widgets/dato_estadistica.dart';

class EstadisticasPage extends StatefulWidget {
  const EstadisticasPage({super.key});

  @override
  State<EstadisticasPage> createState() => _EstadisticasPageState();
}

class _EstadisticasPageState extends State<EstadisticasPage> {
  List<Map<String, dynamic>> _datos = [];

  @override
  void initState() {
    super.initState();
    _cargarEstadisticas();
  }

  void _cargarEstadisticas() async {
    int? userId = await PreferenciasService.getUsuarioId();
    if (userId != null) {
      List<Habito> habitos = await BaseDatos.getHabitosUsuario(userId);
      List<Map<String, dynamic>> temp = [];

      for (var h in habitos) {
        Estadistica? st = await BaseDatos.getEstadisticaHabito(h.id!);
        temp.add({
          'habito': h.nombre,
          'racha': st?.rachaActual ?? 0,
          'total': st?.totalDias ?? 0,
        });
      }

      setState(() {
        _datos = temp;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Estadísticas')),
      body: ListView.builder(
        itemCount: _datos.length,
        itemBuilder: (ctx, i) {
          final item = _datos[i];
          return Card(
            margin: const EdgeInsets.all(8.0),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item['habito'], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  DatoEstadistica(
                    etiqueta: 'Racha actual',
                    valor: '${item['racha']} días',
                    icono: Icons.local_fire_department,
                    color: Colors.orange,
                  ),
                  const SizedBox(height: 4),
                  DatoEstadistica(
                    etiqueta: 'Días completados',
                    valor: '${item['total']} días',
                    icono: Icons.check_circle,
                    color: Colors.green,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
