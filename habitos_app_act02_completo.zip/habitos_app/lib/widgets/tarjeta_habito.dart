import 'package:flutter/material.dart';

class TarjetaHabito extends StatelessWidget {
  final String nombre;
  final int colorHex;
  final bool completadoHoy;
  final IconData icono;
  final VoidCallback onCompletar;
  final VoidCallback onEditar;
  final VoidCallback onEliminar;

  const TarjetaHabito({
    super.key,
    required this.nombre,
    required this.colorHex,
    required this.completadoHoy,
    this.icono = Icons.star,
    required this.onCompletar,
    required this.onEditar,
    required this.onEliminar,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Color(colorHex).withOpacity(0.2),
      child: ListTile(
        leading: Icon(icono, color: Color(colorHex)),
        title: Text(
          nombre,
          style: TextStyle(
            decoration: completadoHoy ? TextDecoration.lineThrough : null,
          ),
        ),
        subtitle: Text(completadoHoy ? '¡Completado hoy!' : 'Pendiente'),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: Icon(completadoHoy ? Icons.check_box : Icons.check_box_outline_blank),
              onPressed: onCompletar,
            ),
            IconButton(icon: const Icon(Icons.edit), onPressed: onEditar),
            IconButton(icon: const Icon(Icons.delete), onPressed: onEliminar),
          ],
        ),
      ),
    );
  }
}
