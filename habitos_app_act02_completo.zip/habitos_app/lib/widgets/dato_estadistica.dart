import 'package:flutter/material.dart';

class DatoEstadistica extends StatelessWidget {
  final String etiqueta;
  final String valor;
  final IconData icono;
  final Color color;

  const DatoEstadistica({
    super.key,
    required this.etiqueta,
    required this.valor,
    required this.icono,
    this.color = Colors.blue,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icono, color: color),
        const SizedBox(width: 8),
        Text('$etiqueta: ', style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(valor),
      ],
    );
  }
}
