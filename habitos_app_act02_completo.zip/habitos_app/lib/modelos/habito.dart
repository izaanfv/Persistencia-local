class Habito {
  final int? id;
  final int usuarioId;
  final String nombre;
  final int colorHex;
  final String fechasCompletado; // Guardado como cadena separada por comas "2026-11-01,2026-11-02"

  Habito({
    this.id,
    required this.usuarioId,
    required this.nombre,
    required this.colorHex,
    required this.fechasCompletado,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'usuario_id': usuarioId,
      'nombre': nombre,
      'color': colorHex,
      'fechas_completado': fechasCompletado,
    };
  }

  factory Habito.fromMap(Map<String, dynamic> map) {
    return Habito(
      id: map['id'],
      usuarioId: map['usuario_id'],
      nombre: map['nombre'],
      colorHex: map['color'],
      fechasCompletado: map['fechas_completado'] ?? '',
    );
  }
}
