import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../modelos/usuario.dart';
import '../modelos/habito.dart';
import '../modelos/estadistica.dart';

class BaseDatos {
  static Database? _db;

  static Future<Database> get instance async {
    if (_db != null) return _db!;
    _db = await _initDB();
    return _db!;
  }

  static Future<Database> _initDB() async {
    String path = join(await getDatabasesPath(), 'habitos_app.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        // Tabla Usuarios
        await db.execute('''
          CREATE TABLE usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario TEXT UNIQUE,
            nombre TEXT,
            apellidos TEXT,
            email TEXT,
            contrasena TEXT,
            fecha_creacion TEXT,
            rol TEXT
          )
        ''');

        // Tabla Habitos
        await db.execute('''
          CREATE TABLE habitos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER,
            nombre TEXT,
            color INTEGER,
            fechas_completado TEXT,
            FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE
          )
        ''');

        // Tabla Estadisticas
        await db.execute('''
          CREATE TABLE estadisticas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            habito_id INTEGER UNIQUE,
            racha_actual INTEGER,
            total_dias INTEGER,
            FOREIGN KEY (habito_id) REFERENCES habitos (id) ON DELETE CASCADE
          )
        ''');

        // Usuario administrador predeterminado
        await db.insert('usuarios', {
          'usuario': 'admin',
          'nombre': 'Admin',
          'apellidos': 'Sistema',
          'email': 'admin@test.com',
          'contrasena': 'admin123',
          'fecha_creacion': DateTime.now().toString().split(' ')[0],
          'rol': 'administrador',
        });
      },
    );
  }

  // --- CRUD USUARIOS ---
  static Future<int> registrarUsuario(Usuario u) async {
    final db = await instance;
    return await db.insert('usuarios', u.toMap());
  }

  static Future<Usuario?> login(String usuario, String contrasena) async {
    final db = await instance;
    List<Map<String, dynamic>> res = await db.query(
      'usuarios',
      where: 'usuario = ? AND contrasena = ?',
      whereArgs: [usuario, contrasena],
    );
    if (res.isNotEmpty) return Usuario.fromMap(res.first);
    return null;
  }

  static Future<List<Usuario>> getTodosUsuarios() async {
    final db = await instance;
    List<Map<String, dynamic>> res = await db.query('usuarios');
    return res.map((e) => Usuario.fromMap(e)).toList();
  }

  static Future<int> eliminarUsuario(int id) async {
    final db = await instance;
    return await db.delete('usuarios', where: 'id = ?', whereArgs: [id]);
  }

  // --- CRUD HÁBITOS Y ESTADÍSTICAS ---
  static Future<int> crearHabito(Habito h) async {
    final db = await instance;
    int habitoId = await db.insert('habitos', h.toMap());
    
    // Crear estadística vacía vinculada
    await db.insert('estadisticas', {
      'habito_id': habitoId,
      'racha_actual': 0,
      'total_dias': 0,
    });
    return habitoId;
  }

  static Future<List<Habito>> getHabitosUsuario(int usuarioId) async {
    final db = await instance;
    List<Map<String, dynamic>> res = await db.query(
      'habitos',
      where: 'usuario_id = ?',
      whereArgs: [usuarioId],
    );
    return res.map((e) => Habito.fromMap(e)).toList();
  }

  static Future<List<Habito>> getTodosHabitos() async {
    final db = await instance;
    List<Map<String, dynamic>> res = await db.query('habitos');
    return res.map((e) => Habito.fromMap(e)).toList();
  }

  static Future<int> actualizarHabito(Habito h) async {
    final db = await instance;
    return await db.update('habitos', h.toMap(), where: 'id = ?', whereArgs: [h.id]);
  }

  static Future<int> eliminarHabito(int id) async {
    final db = await instance;
    await db.delete('estadisticas', where: 'habito_id = ?', whereArgs: [id]);
    return await db.delete('habitos', where: 'id = ?', whereArgs: [id]);
  }

  static Future<void> marcarHabitoCompletado(Habito h) async {
    final db = await instance;
    String hoy = DateTime.now().toString().split(' ')[0];
    List<String> fechas = h.fechasCompletado.isEmpty ? [] : h.fechasCompletado.split(',');

    if (!fechas.contains(hoy)) {
      fechas.add(hoy);
      String nuevasFechas = fechas.join(',');

      await db.update(
        'habitos',
        {'fechas_completado': nuevasFechas},
        where: 'id = ?',
        whereArgs: [h.id],
      );

      int total = fechas.length;
      int racha = total; // Lógica simplificada para DAM2

      await db.update(
        'estadisticas',
        {'racha_actual': racha, 'total_dias': total},
        where: 'habito_id = ?',
        whereArgs: [h.id],
      );
    }
  }

  static Future<Estadistica?> getEstadisticaHabito(int habitoId) async {
    final db = await instance;
    List<Map<String, dynamic>> res = await db.query(
      'estadisticas',
      where: 'habito_id = ?',
      whereArgs: [habitoId],
    );
    if (res.isNotEmpty) return Estadistica.fromMap(res.first);
    return null;
  }

  static Future<List<Estadistica>> getTodasEstadisticas() async {
    final db = await instance;
    List<Map<String, dynamic>> res = await db.query('estadisticas');
    return res.map((e) => Estadistica.fromMap(e)).toList();
  }
}
