import 'package:shared_preferences/shared_preferences.dart';

class PreferenciasService {
  static Future<void> guardarSesion(int idUsuario, String rol) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('usuario_id', idUsuario);
    await prefs.setString('rol', rol);
  }

  static Future<int?> getUsuarioId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt('usuario_id');
  }

  static Future<String?> getRol() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('rol');
  }

  static Future<void> cerrarSesion() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}
